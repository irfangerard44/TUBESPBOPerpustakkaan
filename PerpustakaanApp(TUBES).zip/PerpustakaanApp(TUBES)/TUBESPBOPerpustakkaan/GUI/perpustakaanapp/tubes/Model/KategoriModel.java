package perpustakaanapp.tubes.Model;

/**
 * @author Irfan Gerard W M
 */
public class KategoriModel {

	String id;
	String nama;
	perpustakaanapp.tubes.Model.KoneksiDB db = null;

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getNama() {
		return this.nama;
	}

	public void setNama(String nama) {
		this.nama = nama;
	}

	public KategoriModel() {
		// TODO - implement KategoriModel.KategoriModel
		throw new UnsupportedOperationException();
	}

	public void tambah() {
		// TODO - implement KategoriModel.tambah
		throw new UnsupportedOperationException();
	}

	public void edit() {
		// TODO - implement KategoriModel.edit
		throw new UnsupportedOperationException();
	}

	public void hapus() {
		// TODO - implement KategoriModel.hapus
		throw new UnsupportedOperationException();
	}

	public java.util.List tampil() {
		// TODO - implement KategoriModel.tampil
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param kategori
	 */
	public java.util.List cariIdKategori(String kategori) {
		// TODO - implement KategoriModel.cariIdKategori
		throw new UnsupportedOperationException();
	}

}