package perpustakaanapp.tubes.Model;

/**
 * @author Irfan Gerard W M
 */
public class LaporanModel {

	java.sql.Connection koneksi;

	public LaporanModel() {
		// TODO - implement LaporanModel.LaporanModel
		throw new UnsupportedOperationException();
	}

	public void cetakBukuSemua() {
		// TODO - implement LaporanModel.cetakBukuSemua
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param kategori
	 */
	public void cetakPerKategori(String kategori) {
		// TODO - implement LaporanModel.cetakPerKategori
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param nopinjam
	 */
	public void cetakBuktiPinjam(String nopinjam) {
		// TODO - implement LaporanModel.cetakBuktiPinjam
		throw new UnsupportedOperationException();
	}

}