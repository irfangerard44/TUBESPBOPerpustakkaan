package perpustakaanapp.tubes.Model;

/**
 * @author Irfan Gerard W M
 */
public class PeminjamanDetailModel {

	String id_pinjam;
	String id_buku;
	String kode;
	String judul;
	String pengarang;
	String penerbit;
	KoneksiDB db = null;

	public String getId_pinjam() {
		return this.id_pinjam;
	}

	public void setId_pinjam(String id_pinjam) {
		this.id_pinjam = id_pinjam;
	}

	public String getId_buku() {
		return this.id_buku;
	}

	public void setId_buku(String id_buku) {
		this.id_buku = id_buku;
	}

	public String getKode() {
		return this.kode;
	}

	public void setKode(String kode) {
		this.kode = kode;
	}

	public String getJudul() {
		return this.judul;
	}

	public void setJudul(String judul) {
		this.judul = judul;
	}

	public String getPengarang() {
		return this.pengarang;
	}

	public void setPengarang(String pengarang) {
		this.pengarang = pengarang;
	}

	public String getPenerbit() {
		return this.penerbit;
	}

	public void setPenerbit(String penerbit) {
		this.penerbit = penerbit;
	}

	public PeminjamanDetailModel() {
		// TODO - implement PeminjamanDetailModel.PeminjamanDetailModel
		throw new UnsupportedOperationException();
	}

	public void tambah() {
		// TODO - implement PeminjamanDetailModel.tambah
		throw new UnsupportedOperationException();
	}

	public void hapus() {
		// TODO - implement PeminjamanDetailModel.hapus
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param noPinjam
	 */
	public java.util.List tampilBuku(String noPinjam) {
		// TODO - implement PeminjamanDetailModel.tampilBuku
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param noPinjam
	 */
	public java.util.List cariBuku(String noPinjam) {
		// TODO - implement PeminjamanDetailModel.cariBuku
		throw new UnsupportedOperationException();
	}

}