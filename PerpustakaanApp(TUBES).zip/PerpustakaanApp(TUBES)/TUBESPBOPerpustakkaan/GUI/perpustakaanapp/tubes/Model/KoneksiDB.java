package perpustakaanapp.tubes.Model;

/**
 * @author Irfan Gerard W M
 */
public class KoneksiDB {

	public static Connection koneksi;
	public Statement st;

	public static Connection ambilKoneksi() {
		// TODO - implement KoneksiDB.ambilKoneksi
		throw new UnsupportedOperationException();
	}

	public void koneksi() {
		// TODO - implement KoneksiDB.koneksi
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param rs
	 */
	public void tutupKoneksi(ResultSet rs) {
		// TODO - implement KoneksiDB.tutupKoneksi
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param sql
	 */
	public ResultSet ambilData(String sql) {
		// TODO - implement KoneksiDB.ambilData
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param sql
	 */
	public void simpanData(String sql) {
		// TODO - implement KoneksiDB.simpanData
		throw new UnsupportedOperationException();
	}

}