package perpustakaanapp.tubes.Model;

/**
 * @author Irfan Gerard W M
 */
public class SettingModel {

	String max_buku;
	String batas_pinjam;
	String denda;
	KoneksiDB db = null;

	public String getMax_buku() {
		return this.max_buku;
	}

	public void setMax_buku(String max_buku) {
		this.max_buku = max_buku;
	}

	public String getBatas_pinjam() {
		return this.batas_pinjam;
	}

	public void setBatas_pinjam(String batas_pinjam) {
		this.batas_pinjam = batas_pinjam;
	}

	public String getDenda() {
		return this.denda;
	}

	public void setDenda(String denda) {
		this.denda = denda;
	}

	public SettingModel() {
		// TODO - implement SettingModel.SettingModel
		throw new UnsupportedOperationException();
	}

	public void edit() {
		// TODO - implement SettingModel.edit
		throw new UnsupportedOperationException();
	}

	public java.util.List tampil() {
		// TODO - implement SettingModel.tampil
		throw new UnsupportedOperationException();
	}

}