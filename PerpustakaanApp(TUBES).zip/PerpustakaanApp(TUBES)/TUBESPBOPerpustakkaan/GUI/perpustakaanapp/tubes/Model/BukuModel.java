package perpustakaanapp.tubes.Model;

/**
 * @author Irfan Gerard W M
 */
public class BukuModel {

	String id;
	String kode;
	String judul;
	String pengarang;
	String penerbit;
	String isbn;
	String stok;
	String kategori_id;
	String nama_kategori;
	perpustakaanapp.tubes.Model.KoneksiDB db = null;

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getKode() {
		return this.kode;
	}

	public void setKode(String kode) {
		this.kode = kode;
	}

	public String getJudul() {
		return this.judul;
	}

	public void setJudul(String judul) {
		this.judul = judul;
	}

	public String getPengarang() {
		return this.pengarang;
	}

	public void setPengarang(String pengarang) {
		this.pengarang = pengarang;
	}

	public String getPenerbit() {
		return this.penerbit;
	}

	public void setPenerbit(String penerbit) {
		this.penerbit = penerbit;
	}

	public String getIsbn() {
		return this.isbn;
	}

	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}

	public String getStok() {
		return this.stok;
	}

	public void setStok(String stok) {
		this.stok = stok;
	}

	public String getKategori_id() {
		return this.kategori_id;
	}

	public void setKategori_id(String kategori_id) {
		this.kategori_id = kategori_id;
	}

	public String getNama_kategori() {
		return this.nama_kategori;
	}

	public void setNama_kategori(String nama_kategori) {
		this.nama_kategori = nama_kategori;
	}

	public BukuModel() {
		// TODO - implement BukuModel.BukuModel
		throw new UnsupportedOperationException();
	}

	public void tambah() {
		// TODO - implement BukuModel.tambah
		throw new UnsupportedOperationException();
	}

	public void edit() {
		// TODO - implement BukuModel.edit
		throw new UnsupportedOperationException();
	}

	public void hapus() {
		// TODO - implement BukuModel.hapus
		throw new UnsupportedOperationException();
	}

	public java.util.List tampil() {
		// TODO - implement BukuModel.tampil
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param cari
	 */
	public java.util.List cariBuku(String cari) {
		// TODO - implement BukuModel.cariBuku
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param id
	 * @param jmlPinjam
	 */
	public void updateStokBuku(String id, int jmlPinjam) {
		// TODO - implement BukuModel.updateStokBuku
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param id
	 * @param jmlPinjam
	 */
	public void kembalikanStokBuku(String id, int jmlPinjam) {
		// TODO - implement BukuModel.kembalikanStokBuku
		throw new UnsupportedOperationException();
	}

}