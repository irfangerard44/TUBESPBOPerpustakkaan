package perpustakaanapp.tubes.Model;

/**
 * @author Irfan Gerard W M
 */
public class PeminjamanModel {

	String id;
	String no_pinjam;
	String tgl_pinjam;
	String tgl_kembali;
	String anggota_id;
	String nama_anggota;
	KoneksiDB db = null;

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getNo_pinjam() {
		return this.no_pinjam;
	}

	public void setNo_pinjam(String no_pinjam) {
		this.no_pinjam = no_pinjam;
	}

	public String getTgl_pinjam() {
		return this.tgl_pinjam;
	}

	public void setTgl_pinjam(String tgl_pinjam) {
		this.tgl_pinjam = tgl_pinjam;
	}

	public String getTgl_kembali() {
		return this.tgl_kembali;
	}

	public void setTgl_kembali(String tgl_kembali) {
		this.tgl_kembali = tgl_kembali;
	}

	public String getAnggota_id() {
		return this.anggota_id;
	}

	public void setAnggota_id(String anggota_id) {
		this.anggota_id = anggota_id;
	}

	public String getNama_anggota() {
		return this.nama_anggota;
	}

	public void setNama_anggota(String nama_anggota) {
		this.nama_anggota = nama_anggota;
	}

	public PeminjamanModel() {
		// TODO - implement PeminjamanModel.PeminjamanModel
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param tgl1
	 * @param tgl2
	 */
	public java.util.List tampilBerdasarkanTgl(String tgl1, String tgl2) {
		// TODO - implement PeminjamanModel.tampilBerdasarkanTgl
		throw new UnsupportedOperationException();
	}

	public void tambah() {
		// TODO - implement PeminjamanModel.tambah
		throw new UnsupportedOperationException();
	}

	public void hapus() {
		// TODO - implement PeminjamanModel.hapus
		throw new UnsupportedOperationException();
	}

	public String buatNoPinjam() {
		// TODO - implement PeminjamanModel.buatNoPinjam
		throw new UnsupportedOperationException();
	}

	public String ambilIdTerakhir() {
		// TODO - implement PeminjamanModel.ambilIdTerakhir
		throw new UnsupportedOperationException();
	}

}