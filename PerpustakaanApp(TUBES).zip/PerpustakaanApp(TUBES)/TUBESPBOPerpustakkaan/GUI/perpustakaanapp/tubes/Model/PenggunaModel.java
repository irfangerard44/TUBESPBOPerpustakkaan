package perpustakaanapp.tubes.Model;

/**
 * @author Irfan Gerard W M
 */
public class PenggunaModel {

	String id;
	String nama;
	String telp;
	String alamat;
	String username;
	String password;
	String hakakses;
	KoneksiDB db = null;

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getNama() {
		return this.nama;
	}

	public void setNama(String nama) {
		this.nama = nama;
	}

	public String getTelp() {
		return this.telp;
	}

	public void setTelp(String telp) {
		this.telp = telp;
	}

	public String getAlamat() {
		return this.alamat;
	}

	public void setAlamat(String alamat) {
		this.alamat = alamat;
	}

	public String getUsername() {
		return this.username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getHakakses() {
		return this.hakakses;
	}

	public void setHakakses(String hakakses) {
		this.hakakses = hakakses;
	}

	public PenggunaModel() {
		// TODO - implement PenggunaModel.PenggunaModel
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param user
	 * @param pass
	 */
	public java.util.List cariLogin(String user, String pass) {
		// TODO - implement PenggunaModel.cariLogin
		throw new UnsupportedOperationException();
	}

}